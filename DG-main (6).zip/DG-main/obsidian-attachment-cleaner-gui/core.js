/**
 * Core logic voor Obsidian Attachment Cleaner
 * Deze functies kunnen zowel in Electron als in Node.js worden gebruikt
 */

const fs = require('fs-extra');
const path = require('path');
const glob = require('glob');

const DEFAULT_ATTACHMENT_PATTERNS = ['*.png', '*.jpg', '*.jpeg', '*.gif', '*.pdf', '*.webp', '*.svg', '*.mp4', '*.mov', '*.mp3', '*.wav', '*.heic', '*.heif'];

function escapeRegExp(string) {
  return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function getFileName(filePath) {
  return path.basename(filePath);
}

function getFileNameWithoutExt(filePath) {
  const baseName = path.basename(filePath);
  return baseName.replace(path.extname(baseName), '');
}

function findAllMarkdownFiles(vaultPath) {
  return glob.sync(path.join(vaultPath, '**', '*.md'), {
    ignore: ['**/node_modules/**', '**/.git/**', '**/.obsidian/**'],
    nodir: true
  });
}

function findAllAttachments(vaultPath, includePatterns, excludePatterns) {
  const allAttachments = [];
  
  for (const pattern of includePatterns) {
    const files = glob.sync(path.join(vaultPath, '**', pattern), {
      ignore: ['**/node_modules/**', '**/.git/**', '**/.obsidian/**'],
      nodir: true
    });
    allAttachments.push(...files);
  }
  
  if (excludePatterns.length > 0) {
    const filteredAttachments = [];
    for (const file of allAttachments) {
      let shouldExclude = false;
      for (const excludePattern of excludePatterns) {
        if (file.includes(excludePattern)) {
          shouldExclude = true;
          break;
        }
      }
      if (!shouldExclude) {
        filteredAttachments.push(file);
      }
    }
    return filteredAttachments;
  }
  
  return allAttachments;
}

function isAttachmentUsed(attachmentPath, markdownFiles) {
  const fileName = getFileName(attachmentPath);
  const fileNameWithoutExt = getFileNameWithoutExt(attachmentPath);
  
  const escapedFileName = escapeRegExp(fileName);
  const escapedFileNameWithoutExt = escapeRegExp(fileNameWithoutExt);
  
  for (const mdFile of markdownFiles) {
    try {
      const content = fs.readFileSync(mdFile, 'utf8');
      
      // Check 1: Exacte match van de volledige bestandsnaam
      if (content.includes(fileName)) {
        return true;
      }
      
      // Check 2: Match zonder extensie (voor [[wiki-links]])
      const wikiLinkPattern = new RegExp("\\[\\[\\s*" + escapedFileNameWithoutExt + "\\.[a-zA-Z0-9]+\\s*\\]\\]|" +
                                          "\\[\\[\\s*" + escapedFileNameWithoutExt + "\\s*\\]\\]", 'i');
      if (wikiLinkPattern.test(content)) {
        return true;
      }
      
      // Check 3: Markdown links
      const mdLinkPattern = new RegExp("\\([^)]*" + escapedFileName + "\\)", 'i');
      if (mdLinkPattern.test(content)) {
        return true;
      }
      
      // Check 4: HTML-style links
      const htmlLinkPattern = new RegExp("<[^>]*" + escapedFileName + "[^>]*>", 'i');
      if (htmlLinkPattern.test(content)) {
        return true;
      }
      
      // Check 5: URL-encoded bestandsnamen
      const urlEncodedFileName = encodeURIComponent(fileName);
      if (content.includes(urlEncodedFileName)) {
        return true;
      }
      
      // Check 6: YAML frontmatter
      const yamlPattern = new RegExp(escapedFileNameWithoutExt + "\\s*:.*", 'i');
      if (yamlPattern.test(content)) {
        return true;
      }
      
    } catch (error) {
      console.error(`Fout bij lezen van ${mdFile}: ${error.message}`);
    }
  }
  
  return false;
}

function scanVault(vaultPath, includePatterns, excludePatterns) {
  const markdownFiles = findAllMarkdownFiles(vaultPath);
  const attachmentFiles = findAllAttachments(vaultPath, includePatterns, excludePatterns);
  
  const results = [];
  
  for (const attachment of attachmentFiles) {
    const relativePath = path.relative(vaultPath, attachment);
    const isUsed = isAttachmentUsed(attachment, markdownFiles);
    
    results.push({
      path: relativePath,
      fullPath: attachment,
      used: isUsed
    });
  }
  
  return {
    total: attachmentFiles.length,
    used: results.filter(r => r.used).length,
    unused: results.filter(r => !r.used).length,
    results: results,
    markdownFiles: markdownFiles.length
  };
}

async function deleteAttachments(attachments) {
  let deletedCount = 0;
  const errors = [];
  
  for (const attachment of attachments) {
    try {
      await fs.remove(attachment);
      deletedCount++;
    } catch (error) {
      errors.push({ path: attachment, error: error.message });
    }
  }
  
  return { deletedCount, errors };
}

module.exports = {
  DEFAULT_ATTACHMENT_PATTERNS,
  escapeRegExp,
  getFileName,
  getFileNameWithoutExt,
  findAllMarkdownFiles,
  findAllAttachments,
  isAttachmentUsed,
  scanVault,
  deleteAttachments
};
