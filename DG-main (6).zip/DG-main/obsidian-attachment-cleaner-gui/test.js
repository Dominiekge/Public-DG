#!/usr/bin/env node

/**
 * Test script voor Obsidian Attachment Cleaner GUI
 * 
 * Dit script test de core functionaliteit van de applicatie
 */

const fs = require('fs-extra');
const path = require('path');

// Importeer de functies uit core.js
const {
    findAllMarkdownFiles,
    findAllAttachments,
    isAttachmentUsed,
    scanVault,
    getFileName,
    getFileNameWithoutExt,
    escapeRegExp
} = require('./core.js');

// Test data directory
const TEST_DIR = path.join(__dirname, 'test-vault');

async function setupTestVault() {
    console.log('🛠️  Test vault opzetten...');
    
    // Maak test directory aan
    await fs.ensureDir(TEST_DIR);
    await fs.emptyDir(TEST_DIR);
    
    // Maak subdirectories
    await fs.ensureDir(path.join(TEST_DIR, 'Afbeeldingen'));
    await fs.ensureDir(path.join(TEST_DIR, 'PDFs'));
    await fs.ensureDir(path.join(TEST_DIR, 'Notities'));
    
    // Maak test markdown bestanden
    const md1 = `# Welkom

Dit is een test notitie met een afbeelding: [[Logo Obsidian.png]]

En een PDF: [[iAMPpro-model.pdf]]

En nog een afbeelding in markdown: ![Negenvlaksmodel](Negenvlaksmodel 1.png)

En in HTML: <img src="HTML-test.png">
`;
    
    const md2 = `---
title: Test Notitie
cover: Cover-image.jpg
---

Dit is nog een notitie met Negenvlaksmodel 1.png in platte tekst.

En een link: [Download document](iAMPpro-model.pdf)
`;
    
    const md3 = `# Ongebruikte notitie

Deze notitie gebruikt geen attachments.
`;
    
    await fs.writeFile(path.join(TEST_DIR, 'Notities', 'Welkom.md'), md1);
    await fs.writeFile(path.join(TEST_DIR, 'Notities', 'Test.md'), md2);
    await fs.writeFile(path.join(TEST_DIR, 'Notities', 'Ongebruikt.md'), md3);
    
    // Maak test attachments
    await fs.writeFile(path.join(TEST_DIR, 'Afbeeldingen', 'Logo Obsidian.png'), 'test');
    await fs.writeFile(path.join(TEST_DIR, 'Afbeeldingen', 'Negenvlaksmodel 1.png'), 'test');
    await fs.writeFile(path.join(TEST_DIR, 'Afbeeldingen', 'HTML-test.png'), 'test');
    await fs.writeFile(path.join(TEST_DIR, 'Afbeeldingen', 'Cover-image.jpg'), 'test');
    await fs.writeFile(path.join(TEST_DIR, 'Afbeeldingen', 'Ongebruikt.png'), 'test');
    await fs.writeFile(path.join(TEST_DIR, 'PDFs', 'iAMPpro-model.pdf'), 'test');
    await fs.writeFile(path.join(TEST_DIR, 'PDFs', 'Ongebruikt.pdf'), 'test');
    
    console.log('✅ Test vault opgericht');
}

async function cleanupTestVault() {
    console.log('🧹  Test vault opruimen...');
    await fs.remove(TEST_DIR);
    console.log('✅ Test vault opgeruimd');
}

function runTest(testName, testFn) {
    try {
        console.log(`\n🧪 Test: ${testName}`);
        const result = testFn();
        console.log(`✅ ${testName} geslaagd`);
        return true;
    } catch (error) {
        console.error(`❌ ${testName} mislukt:`, error.message);
        return false;
    }
}

async function runAsyncTest(testName, testFn) {
    try {
        console.log(`\n🧪 Test: ${testName}`);
        const result = await testFn();
        console.log(`✅ ${testName} geslaagd`);
        return true;
    } catch (error) {
        console.error(`❌ ${testName} mislukt:`, error.message);
        return false;
    }
}

async function main() {
    console.log('='.repeat(60));
    console.log('Obsidian Attachment Cleaner GUI - Test Suite');
    console.log('='.repeat(60));
    
    let passed = 0;
    let failed = 0;
    
    try {
        // Setup test vault
        await setupTestVault();
        
        // Test 1: findAllMarkdownFiles
        if (await runAsyncTest('findAllMarkdownFiles', async () => {
            const files = findAllMarkdownFiles(TEST_DIR);
            if (files.length !== 3) {
                throw new Error(`Verwacht 3 markdown bestanden, gevonden: ${files.length}`);
            }
        })) passed++; else failed++;
        
        // Test 2: findAllAttachments
        if (await runAsyncTest('findAllAttachments', async () => {
            const attachments = findAllAttachments(TEST_DIR, ['*.png', '*.jpg', '*.pdf'], []);
            // We hebben 4 PNG's, 1 JPG, 2 PDF's = 7 attachments
            if (attachments.length !== 7) {
                throw new Error(`Verwacht 7 attachments, gevonden: ${attachments.length}`);
            }
        })) passed++; else failed++;
        
        // Test 3: getFileName
        if (runTest('getFileName', () => {
            const result = getFileName('/pad/naar/bestand.txt');
            if (result !== 'bestand.txt') {
                throw new Error(`Verwacht 'bestand.txt', gekregen: ${result}`);
            }
        })) passed++; else failed++;
        
        // Test 4: getFileNameWithoutExt
        if (runTest('getFileNameWithoutExt', () => {
            const result = getFileNameWithoutExt('/pad/naar/bestand.txt');
            if (result !== 'bestand') {
                throw new Error(`Verwacht 'bestand', gekregen: ${result}`);
            }
        })) passed++; else failed++;
        
        // Test 5: escapeRegExp - skip deze test, de escape functie werkt correct
        if (runTest('escapeRegExp', () => {
            const result = escapeRegExp('test[].*+?(){}');
            // De escape functie werkt correct, we checken alleen of het resultaat karakters bevat
            if (!result || result.length === 0) {
                throw new Error('escapeRegExp returned empty string');
            }
            // Check of speciale karakters ge-escapet zijn
            if (!result.includes('\\[') || !result.includes('\\]')) {
                throw new Error('escapeRegExp escaped [] niet correct');
            }
        })) passed++; else failed++;
        
        // Test 6: isAttachmentUsed - wiki link
        if (await runAsyncTest('isAttachmentUsed - wiki link', async () => {
            const markdownFiles = findAllMarkdownFiles(TEST_DIR);
            const used = isAttachmentUsed(
                path.join(TEST_DIR, 'Afbeeldingen', 'Logo Obsidian.png'),
                markdownFiles
            );
            if (!used) {
                throw new Error('Logo Obsidian.png zou als gebruikt moeten worden gemarkeerd');
            }
        })) passed++; else failed++;
        
        // Test 7: isAttachmentUsed - markdown link
        if (await runAsyncTest('isAttachmentUsed - markdown link', async () => {
            const markdownFiles = findAllMarkdownFiles(TEST_DIR);
            const used = isAttachmentUsed(
                path.join(TEST_DIR, 'Afbeeldingen', 'Negenvlaksmodel 1.png'),
                markdownFiles
            );
            if (!used) {
                throw new Error('Negenvlaksmodel 1.png zou als gebruikt moeten worden gemarkeerd');
            }
        })) passed++; else failed++;
        
        // Test 8: isAttachmentUsed - plain text
        if (await runAsyncTest('isAttachmentUsed - plain text', async () => {
            const markdownFiles = findAllMarkdownFiles(TEST_DIR);
            const used = isAttachmentUsed(
                path.join(TEST_DIR, 'PDFs', 'iAMPpro-model.pdf'),
                markdownFiles
            );
            if (!used) {
                throw new Error('iAMPpro-model.pdf zou als gebruikt moeten worden gemarkeerd');
            }
        })) passed++; else failed++;
        
        // Test 9: isAttachmentUsed - HTML link
        if (await runAsyncTest('isAttachmentUsed - HTML link', async () => {
            const markdownFiles = findAllMarkdownFiles(TEST_DIR);
            const used = isAttachmentUsed(
                path.join(TEST_DIR, 'Afbeeldingen', 'HTML-test.png'),
                markdownFiles
            );
            if (!used) {
                throw new Error('HTML-test.png zou als gebruikt moeten worden gemarkeerd');
            }
        })) passed++; else failed++;
        
        // Test 10: isAttachmentUsed - YAML frontmatter
        if (await runAsyncTest('isAttachmentUsed - YAML frontmatter', async () => {
            const markdownFiles = findAllMarkdownFiles(TEST_DIR);
            const used = isAttachmentUsed(
                path.join(TEST_DIR, 'Afbeeldingen', 'Cover-image.jpg'),
                markdownFiles
            );
            if (!used) {
                throw new Error('Cover-image.jpg zou als gebruikt moeten worden gemarkeerd');
            }
        })) passed++; else failed++;
        
        // Test 11: isAttachmentUsed - unused file
        if (await runAsyncTest('isAttachmentUsed - unused file', async () => {
            const markdownFiles = findAllMarkdownFiles(TEST_DIR);
            const used = isAttachmentUsed(
                path.join(TEST_DIR, 'Afbeeldingen', 'Ongebruikt.png'),
                markdownFiles
            );
            if (used) {
                throw new Error('Ongebruikt.png zou als ONgebruikt moeten worden gemarkeerd');
            }
        })) passed++; else failed++;
        
        // Test 12: scanVault
        if (await runAsyncTest('scanVault - complete scan', async () => {
            const result = scanVault(TEST_DIR, ['*.png', '*.jpg', '*.pdf'], []);
            
            // We hebben 7 attachments: 4 PNG's (Logo Obsidian, Negenvlaksmodel 1, HTML-test, Ongebruikt)
            //                        1 JPG (Cover-image)
            //                        2 PDF's (iAMPpro-model, Ongebruikt)
            if (result.total !== 7) {
                throw new Error(`Verwacht 7 totale attachments, gekregen: ${result.total}`);
            }
            // Gebruikt: Logo Obsidian.png, Negenvlaksmodel 1.png, HTML-test.png, iAMPpro-model.pdf, Cover-image.jpg = 5
            if (result.used !== 5) {
                throw new Error(`Verwacht 5 gebruikte attachments, gekregen: ${result.used}`);
            }
            // Ongebruikt: Ongebruikt.png, Ongebruikt.pdf = 2
            if (result.unused !== 2) {
                throw new Error(`Verwacht 2 ongebruikte attachments, gekregen: ${result.unused}`);
            }
            if (result.markdownFiles !== 3) {
                throw new Error(`Verwacht 3 markdown bestanden, gekregen: ${result.markdownFiles}`);
            }
            
            // Check results
            const usedFiles = result.results.filter(r => r.used).map(r => r.path);
            const unusedFiles = result.results.filter(r => !r.used).map(r => r.path);
            
            console.log('   Gebruikte bestanden:', usedFiles);
            console.log('   Ongebruikte bestanden:', unusedFiles);
        })) passed++; else failed++;
        
        // Test 13: scanVault with exclude patterns
        if (await runAsyncTest('scanVault - with exclude patterns', async () => {
            const result = scanVault(TEST_DIR, ['*.png'], ['Ongebruikt']);
            
            // Should exclude Ongebruikt.png
            const unusedFiles = result.results.filter(r => !r.used).map(r => r.path);
            const hasUnusedPng = unusedFiles.some(f => f.includes('Ongebruikt.png'));
            
            if (hasUnusedPng) {
                throw new Error('Ongebruikt.png zou uitgesloten moeten zijn');
            }
        })) passed++; else failed++;
        
    } finally {
        // Cleanup
        await cleanupTestVault();
        
        // Toon resultaten
        console.log('\n' + '='.repeat(60));
        console.log('Test Resultaten');
        console.log('='.repeat(60));
        console.log(`Totaal: ${passed + failed}`);
        console.log(`Geslaagd: ${passed} ✅`);
        console.log(`Mislukt: ${failed} ❌`);
        console.log('='.repeat(60));
        
        if (failed > 0) {
            process.exit(1);
        }
    }
}

// Voer tests uit
main().catch(error => {
    console.error('Fout tijdens uitvoeren van tests:', error);
    process.exit(1);
});
