const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  selectDirectory: () => ipcRenderer.invoke('select-directory'),
  scanVault: (options) => ipcRenderer.invoke('scan-vault', options),
  deleteAttachments: (options) => ipcRenderer.invoke('delete-attachments', options),
  onUpdate: (callback) => ipcRenderer.on('update', callback),
  removeAllListeners: (channel) => ipcRenderer.removeAllListeners(channel)
});
