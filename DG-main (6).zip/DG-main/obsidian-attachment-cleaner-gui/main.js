const { app, BrowserWindow, ipcMain, dialog } = require('electron');
const path = require('path');
const {
  DEFAULT_ATTACHMENT_PATTERNS,
  scanVault,
  deleteAttachments
} = require('./core.js');

let mainWindow;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1000,
    height: 800,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      enableRemoteModule: false,
      preload: path.join(__dirname, 'preload.js')
    }
  });
  
  mainWindow.loadFile('index.html');
  
  // Open DevTools in development
  // mainWindow.webContents.openDevTools();
  
  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

// IPC handlers
ipcMain.handle('select-directory', async () => {
  const result = await dialog.showOpenDialog({
    properties: ['openDirectory'],
    title: 'Selecteer Obsidian Vault Map'
  });
  
  return result.filePaths[0] || null;
});

ipcMain.handle('scan-vault', async (event, { vaultPath, includePatterns, excludePatterns }) => {
  try {
    const normalizedVaultPath = path.resolve(vaultPath);
    const patterns = includePatterns || DEFAULT_ATTACHMENT_PATTERNS;
    const excludes = excludePatterns || [];
    
    return await scanVault(normalizedVaultPath, patterns, excludes);
  } catch (error) {
    return { error: error.message };
  }
});

ipcMain.handle('delete-attachments', async (event, { attachments }) => {
  try {
    return await deleteAttachments(attachments);
  } catch (error) {
    return { error: error.message };
  }
});

app.whenReady().then(() => {
  createWindow();
  
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    }
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});
