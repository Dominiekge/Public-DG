@echo off
chcp 65001 >nul
title Obsidian Attachment Cleaner - Eenvoudig

:: ============================================================
:: Eenvoudige Obsidian Attachment Cleaner
:: Dubbelklik op dit bestand om te gebruiken
:: GEEN Node.js, PowerShell of andere tools nodig!
:: ============================================================

setlocal enabledelayedexpansion

:: Standaard extensies om te scannen
set "INCLUDE_EXT=png jpg jpeg gif pdf webp svg"

:: Functie: Selecteer map met GUI
:SelectFolder
set "FOLDER_PATH="
set "HTA_FILE=%temp%\select_folder.hta"

:: Maak HTA bestand voor map selectie
echo HTML^>^<html^>^<head^>^<title^>Selecteer Obsidian Vault^</title^> > "%HTA_FILE%"
echo ^<HTA:APPLICATION ID="FolderSelect" APPLICATIONNAME="Map Selecteren" BORDER="dialog" BORDERSTYLE="normal" CAPTION="yes" SHOWINTASKBAR="yes" SYSMENU="yes"/^> >> "%HTA_FILE%"
echo ^<script language="VBScript"^> >> "%HTA_FILE%"
echo Function BrowseFolder() >> "%HTA_FILE%"
echo     Set objShell = CreateObject("Shell.Application") >> "%HTA_FILE%"
echo     Set objFolder = objShell.BrowseForFolder(0, "Selecteer je Obsidian Vault Map", 0, 0).Items() >> "%HTA_FILE%"
echo     If Not objFolder Is Nothing Then >> "%HTA_FILE%"
echo         window.returnValue = objFolder.Path >> "%HTA_FILE%"
echo         window.close >> "%HTA_FILE%"
echo     End If >> "%HTA_FILE%"
echo End Function >> "%HTA_FILE%"
echo ^</script^> >> "%HTA_FILE%"
echo ^</head^>^<body onload="BrowseFolder()"^>^</body^>^</html^> >> "%HTA_FILE%"

mshta "%HTA_FILE%" > "%temp%\folder_result.txt" 2>nul
del "%HTA_FILE%" >nul 2>&1

for /f "delims=" %%F in ('type "%temp%\folder_result.txt" 2^>nul') do set "FOLDER_PATH=%%F"
del "%temp%\folder_result.txt" >nul 2>&1

exit /b %FOLDER_PATH%

:: ============================================================
:: HOOFDPROGRAMMA
:: ============================================================

echo ==========================================================
echo       Obsidian Attachment Cleaner - Eenvoudige Versie
echo ==========================================================
echo.

:: Vraag om vault pad
call :SelectFolder
set "VAULT_PATH=%FOLDER_PATH%"

if "%VAULT_PATH%"=="" (
    echo Geen map geselecteerd!
    pause
    exit /b 1
)

:: Controleer of pad bestaat
if not exist "%VAULT_PATH%\" (
    echo Fout: Het pad bestaat niet: %VAULT_PATH%
    pause
    exit /b 1
)

:: Normaliseer pad
if "%VAULT_PATH:~-1%"=="\" set "VAULT_PATH=%VAULT_PATH:~0,-1%"

echo Vault pad: %VAULT_PATH%
echo.

:: Tel markdown bestanden
set MD_COUNT=0
for /r "%VAULT_PATH%" %%F in (*.md) do (
    set /a MD_COUNT+=1
)
echo Gevonden %MD_COUNT% markdown bestanden

:: Maak tijdelijke bestanden
set "UNUSED_FILE=%temp%\obsidian_unused_%random%.txt"
if exist "%UNUSED_FILE%" del "%UNUSED_FILE%" >nul 2>&1

:: Zoek ongebruikte attachments
echo.
echo Scannen van attachments...

set UNUSED_COUNT=0

for %%E in (%INCLUDE_EXT%) do (
    for /r "%VAULT_PATH%" %%F in (*.%%E) do (
        :: Skip node_modules, .git, .obsidian
        echo %%F | findstr /i "\node_modules\ \.git\ \.obsidian\" >nul
        if !errorlevel! equ 0 (
            goto :skip_file
        )
        
        set "FILENAME=%%~nxF"
        set "USAGE_FOUND=0"
        
        :: Zoek in alle .md bestanden
        for /r "%VAULT_PATH%" %%M in (*.md) do (
            findstr /i /c:"!FILENAME!" "%%M" >nul 2>&1
            if !errorlevel! equ 0 (
                set "USAGE_FOUND=1"
                goto :check_next
            )
        )
        
        :: Check als wiki-link [[filename]]
        for /r "%VAULT_PATH%" %%M in (*.md) do (
            findstr /i /c:"[[!FILENAME!" "%%M" >nul 2>&1
            if !errorlevel! equ 0 (
                set "USAGE_FOUND=1"
                goto :check_next
            )
        )
        
        :: Check als markdown link (filename)
        for /r "%VAULT_PATH%" %%M in (*.md) do (
            findstr /i /c:"(!FILENAME!" "%%M" >nul 2>&1
            if !errorlevel! equ 0 (
                set "USAGE_FOUND=1"
                goto :check_next
            )
        )
        
        :: Als niet gevonden, voeg toe aan ongebruikte lijst
        echo %%F >> "%UNUSED_FILE%"
        set /a UNUSED_COUNT+=1
        
        :check_next
        :skip_file
    )
)

:: Toon resultaten
echo.
echo ==========================================================
echo                    SCAN RESULTATEN
==========================================================
echo.

:: Tel totale attachments
set TOTAL_ATT=0
for %%E in (%INCLUDE_EXT%) do (
    for /r "%VAULT_PATH%" %%F in (*.%%E) do (
        echo %%F | findstr /i "\node_modules\ \.git\ \.obsidian\" >nul
        if !errorlevel! equ 0 (
            goto :skip_count
        )
        set /a TOTAL_ATT+=1
        :skip_count
    )
)

set /a USED_COUNT=TOTAL_ATT - UNUSED_COUNT

echo Samenvatting:
echo   Totaal attachments: %TOTAL_ATT%
echo   Gebruikte attachments: %USED_COUNT%
echo   Ongebruikte attachments: %UNUSED_COUNT%
echo   Markdown bestanden: %MD_COUNT%
echo ==========================================================

if %UNUSED_COUNT% equ 0 (
    echo.
    echo Alle attachments worden gebruikt! Er is niets om te verwijderen.
    pause
    exit /b 0
)

echo.
echo Ongebruikte attachments:
echo --------------------------------------------

:: Toon ongebruikte bestanden
for /f "delims=" %%F in ('type "%UNUSED_FILE%" 2^>nul') do (
    set "REL_PATH=%%F"
    set "REL_PATH=!REL_PATH:%VAULT_PATH%\=!"
    echo   X !REL_PATH!
)

echo.
echo Wil je deze %UNUSED_COUNT% ongebruikte attachments verwijderen?
echo Typ JA om te verwijderen, of druk op Enter om te annuleren
echo.
set /p "CONFIRM=Bevestigen (JA/Nee): "

if /i "%CONFIRM%"=="JA" (
    echo.
    echo LET OP: Dit verwijdert bestanden PERMANENT!
    echo.
    
    set DELETE_COUNT=0
    for /f "delims=" %%F in ('type "%UNUSED_FILE%" 2^>nul') do (
        del "%%F" >nul 2>&1
        if !errorlevel! equ 0 (
            set /a DELETE_COUNT+=1
            set "REL_PATH=%%F"
            set "REL_PATH=!REL_PATH:%VAULT_PATH%\=!"
            echo   Verwijderd: !REL_PATH!
        ) else (
            set "REL_PATH=%%F"
            set "REL_PATH=!REL_PATH:%VAULT_PATH%\=!"
            echo   Fout bij verwijderen: !REL_PATH!
        )
    )
    
    echo.
    echo Succes: %DELETE_COUNT% van %UNUSED_COUNT% ongebruikte attachments verwijderd
) else (
    echo Geannuleerd - geen bestanden verwijderd
)

:: Schoonmaken
del "%UNUSED_FILE%" >nul 2>&1

echo.
pause
