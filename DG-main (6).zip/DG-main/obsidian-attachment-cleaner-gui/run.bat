@echo off
chcp 65001 >nul
title Obsidian Attachment Cleaner GUI

:: Check if Node.js is installed
where node >nul 2>&1
if %errorlevel% neq 0 (
    echo [31m❌ Fout: Node.js is niet geïnstalleerd[0m
    echo Installeer Node.js eerst: https://nodejs.org
    pause
    exit /b 1
)

:: Navigate to script directory
cd /d "%~dp0"

:: Check if dependencies are installed
if not exist "node_modules" (
    echo [33m⏳ Afhankelijkheden installeren...[0m
    npm install
    if %errorlevel% neq 0 (
        echo [31m❌ Fout bij installeren van afhankelijkheden[0m
        pause
        exit /b 1
    )
)

:: Start the Electron app
echo [32m✅ Obsidian Attachment Cleaner GUI starten...[0m
echo.
start npm start
