' Obsidian Attachment Cleaner - VBScript versie
' Een eenvoudige GUI voor het selecteren van vault pad en uitvoeren van PowerShell script
' 
' Dit script vereist PowerShell 5.0 of hoger

Option Explicit

Dim objShell, objFSO, vaultPath, wshShell, scriptPath

' Maak objecten aan
Set objShell = CreateObject("WScript.Shell")
Set objFSO = CreateObject("Scripting.FileSystemObject")
Set wshShell = CreateObject("WScript.Shell")

' Get script directory
scriptPath = objFSO.GetParentFolderName(WScript.ScriptFullName)

' Check if PowerShell is available
If Not objFSO.FileExists(objFSO.BuildPath(objShell.ExpandEnvironmentStrings("%SystemRoot%"), "System32\WindowsPowerShell\v1.0\powershell.exe")) Then
    MsgBox "PowerShell is niet geïnstalleerd. Download het van https://aka.ms/windowspowershell", vbCritical, "Fout"
    WScript.Quit 1
End If

' Check PowerShell version
Dim psVersion, psCheck
On Error Resume Next
psCheck = wshShell.Run("powershell -command ""$PSVersionTable.PSVersion.Major""", 0, True)
If Err.Number <> 0 Then
    MsgBox "Kan PowerShell versie niet controleren: " & Err.Description, vbExclamation, "Waarschuwing"
End If
On Error GoTo 0

' Function to show folder picker dialog
Function BrowseForFolder(initialPath)
    Dim objFolder, objItem
    
    Set objFolder = CreateObject("Shell.Application").BrowseForFolder(0, "Selecteer je Obsidian Vault Map", 0, initialPath)
    
    If Not objFolder Is Nothing Then
        BrowseForFolder = objFolder.Items().Item().Path
    Else
        BrowseForFolder = ""
    End If
    
    Set objFolder = Nothing
End Function

' Function to check if path exists
Function PathExists(path)
    On Error Resume Next
    PathExists = objFSO.FolderExists(path)
    On Error GoTo 0
End Function

' Main dialog
Dim result, form

' Create HTML form for better input
Dim htmlFile, tempFile
Set tempFile = objFSO.CreateTextFile(objShell.ExpandEnvironmentStrings("%TEMP%") & "\obsidian_cleaner_input.html", True)

tempFile.WriteLine "<html>"
tempFile.WriteLine "<head>"
tempFile.WriteLine "<title>Obsidian Attachment Cleaner</title>"
tempFile.WriteLine "<HTA:APPLICATION ID='ObsidianCleaner' APPLICATIONNAME='Obsidian Attachment Cleaner' BORDER='dialog' BORDERSTYLE='normal' CAPTION='yes' ICON='imageres.dll,-102' SHOWINTASKBAR='yes' SINGLEINSTANCE='yes' SYSMENU='yes' WINDOWSTATE='normal'/>"
tempFile.WriteLine "<style>"
tempFile.WriteLine "  body { font-family: Segoe UI, Tahoma, Arial, sans-serif; background: #f5f5f5; margin: 20px; }"
tempFile.WriteLine "  h1 { color: #333; }"
tempFile.WriteLine "  .form-group { margin-bottom: 15px; }"
tempFile.WriteLine "  label { display: block; margin-bottom: 5px; font-weight: bold; color: #555; }"
tempFile.WriteLine "  input[type='text'] { width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; }"
tempFile.WriteLine "  button { padding: 10px 20px; background: #0078d7; color: white; border: none; border-radius: 4px; cursor: pointer; margin-right: 10px; }"
tempFile.WriteLine "  button:hover { background: #005fa3; }"
tempFile.WriteLine "  .info { color: #666; font-size: 0.9em; margin-top: 5px; }"
tempFile.WriteLine "</style>"
tempFile.WriteLine "</head>"
tempFile.WriteLine "<body>"
tempFile.WriteLine "<h1>Obsidian Attachment Cleaner</h1>"
tempFile.WriteLine "<p>Selecteer de map waar je Obsidian vault zich bevindt:</p>"
tempFile.WriteLine "<div class='form-group'>"
tempFile.WriteLine "  <label for='vaultPath'>Obsidian Vault Pad:</label>"
tempFile.WriteLine "  <input type='text' id='vaultPath' placeholder='Bijv: C:\\Users\\JouwNaam\\Obsidian\\MijnVault' value=''>"
tempFile.WriteLine "  <div class='info'>Je kunt het pad handmatig typen of bladeren</div>"
tempFile.WriteLine "</div>"
tempFile.WriteLine "<button onclick='browseFolder()'>Bladeren...</button>"
tempFile.WriteLine "<button onclick='runCleaner()'>Start Scan</button>"
tempFile.WriteLine "<button onclick='window.close()'>Annuleren</button>"
tempFile.WriteLine "<script>"
tempFile.WriteLine "  function browseFolder() {"
tempFile.WriteLine "    var shell = new ActiveXObject('Shell.Application');"
tempFile.WriteLine "    var folder = shell.BrowseForFolder(0, 'Selecteer Obsidian Vault Map', 0, 0).items();"
tempFile.WriteLine "    if (folder && folder.item) {"
tempFile.WriteLine "      document.getElementById('vaultPath').value = folder.item.path;"
tempFile.WriteLine "    }"
tempFile.WriteLine "  }"
tempFile.WriteLine "  function runCleaner() {"
tempFile.WriteLine "    var vaultPath = document.getElementById('vaultPath').value;"
tempFile.WriteLine "    if (!vaultPath) {"
tempFile.WriteLine "      alert('Voer eerst een vault pad in');"
tempFile.WriteLine "      return;"
tempFile.WriteLine "    }"
tempFile.WriteLine "    window.close();"
tempFile.WriteLine "    var fso = new ActiveXObject('Scripting.FileSystemObject');"
tempFile.WriteLine "    var tempFile = fso.CreateTextFile(fso.GetSpecialFolder(2) + '\\obsidian_vault_path.txt', true);"
tempFile.WriteLine "    tempFile.WriteLine(vaultPath);"
tempFile.WriteLine "    tempFile.Close();"
tempFile.WriteLine "  }"
tempFile.WriteLine "</script>"
tempFile.WriteLine "</body>"
tempFile.WriteLine "</html>"

tempFile.Close

' Show the dialog
Dim htaPath
htaPath = objShell.ExpandEnvironmentStrings("%TEMP%") & "\obsidian_cleaner_input.html"

On Error Resume Next
wshShell.Run "mshta """ & htaPath & """", 1, True
If Err.Number <> 0 Then
    ' Fallback to simple input
    vaultPath = InputBox("Voer het pad naar je Obsidian vault in:", "Obsidian Attachment Cleaner", "C:\Users\" & objShell.ExpandEnvironmentStrings("%USERNAME%") & "\Obsidian\MijnVault")
    If vaultPath = "" Then
        WScript.Quit 0
    End If
Else
    ' Read the selected path from temp file
    Dim pathFile, selectedPath
    Set pathFile = objFSO.OpenTextFile(objShell.ExpandEnvironmentStrings("%TEMP%") & "\obsidian_vault_path.txt", 1)
    selectedPath = pathFile.ReadLine
    pathFile.Close
    
    If selectedPath <> "" Then
        vaultPath = selectedPath
    Else
        vaultPath = InputBox("Voer het pad naar je Obsidian vault in:", "Obsidian Attachment Cleaner", "C:\Users\" & objShell.ExpandEnvironmentStrings("%USERNAME%") & "\Obsidian\MijnVault")
        If vaultPath = "" Then
            WScript.Quit 0
        End If
    End If
    
    ' Clean up temp files
    On Error Resume Next
    objFSO.DeleteFile(htaPath)
    objFSO.DeleteFile(objShell.ExpandEnvironmentStrings("%TEMP%") & "\obsidian_vault_path.txt")
    On Error GoTo 0
End If

' Check if path exists
If Not PathExists(vaultPath) Then
    MsgBox "Het opgegeven pad bestaat niet: " & vaultPath, vbExclamation, "Fout"
    WScript.Quit 1
End If

' Run the PowerShell script
Dim psCommand
psCommand = "powershell -ExecutionPolicy Bypass -File """ & scriptPath & "\ObsidianAttachmentCleaner.ps1""" -VaultPath " & vaultPath

WScript.Echo "Starten Obsidian Attachment Cleaner..."
WScript.Echo "Vault pad: " & vaultPath
WScript.Echo ""
WScript.Echo "Dit kan even duren afhankelijk van de grootte van je vault..."

wshShell.Run psCommand, 1, True

Set objShell = Nothing
Set objFSO = Nothing
Set wshShell = Nothing
