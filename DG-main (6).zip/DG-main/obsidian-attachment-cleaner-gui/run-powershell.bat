@echo off
chcp 65001 >nul
title Obsidian Attachment Cleaner (PowerShell)

:: Check if PowerShell is available
where powershell >nul 2>&1
if %errorlevel% neq 0 (
    echo [31m❌ Fout: PowerShell is niet beschikbaar[0m
    echo PowerShell is vereist voor deze applicatie
    pause
    exit /b 1
)

:: Check PowerShell version
for /f "tokens=2 delims==" %%v in ('powershell -command "$PSVersionTable.PSVersion.Major" 2^>nul') do (
    set psversion=%%v
)

if %psversion% LSS 5 (
    echo [31m❌ Fout: PowerShell 5.0 of hoger is vereist (gevonden: %psversion%)[0m
    echo Download de nieuwste versie: https://aka.ms/windowspowershell
    pause
    exit /b 1
)

:: Navigate to script directory
cd /d "%~dp0"

:: Check if script exists
if not exist "ObsidianAttachmentCleaner.ps1" (
    echo [31m❌ Fout: ObsidianAttachmentCleaner.ps1 niet gevonden[0m
    pause
    exit /b 1
)

:: Run the PowerShell script
echo [32m✅ Obsidian Attachment Cleaner (PowerShell versie) starten...[0m
echo.
echo Tip: Je kunt ook rechtstreeks het .ps1 bestand uitvoeren
echo.
powershell -ExecutionPolicy Bypass -File "%~dp0ObsidianAttachmentCleaner.ps1" -NoExit
