<#PSScriptInfo

.VERSION 1.0.0
.GUID 5f4e3d2c-1b0a-4f8e-9d7c-6b5a4e3d2c1b
.AUTHOR Dominiek
.COMPANYNAME 
.COPYRIGHT (c) 2024
.TAGS Obsidian, Attachment, Cleaner, Markdown
.LICENSEURI https://opensource.org/licenses/MIT
.PROJECTURI https://github.com/Dominiekge/DG
.ICONURI 
.EXTERNALMODULEDEPENDENCIES 
.REQUIREDSCRIPTS 
.EXTERNALSCRIPTDEPENDENCIES 
.RELEASENOTES 
.PRIVATEDATA

#>
<#
.SYNOPSIS
    Obsidian Attachment Cleaner - Verwijder ongebruikte attachments uit Obsidian vaults
.DESCRIPTION
    Deze PowerShell script scant je Obsidian vault op ongebruikte afbeeldingen en PDF's.
    Het zoekt naar bestandsnamen in:
    - Platte tekst (bijv: "Negenvlaksmodel 1.png")
    - Wiki-links (bijv: [[Logo Obsidian.png]])
    - Markdown links (bijv: ![alt](afbeelding.png))
    - HTML links (bijv: <img src="afbeelding.png">)
    - YAML frontmatter

.PARAMETER VaultPath
    Het pad naar je Obsidian vault
.PARAMETER IncludePatterns
    Patronen voor bestanden om te scannen (komma gescheiden)
.PARAMETER ExcludePatterns
    Patronen om uit te sluiten (komma gescheiden)
.PARAMETER Delete
    Verwijder ongebruikte bestanden (zonder deze switch wordt alleen getoond)
.PARAMETER WhatIf
    Toon wat er zou gebeuren zonder daadwerkelijk te verwijderen
.EXAMPLE
    .\ObsidianAttachmentCleaner.ps1 -VaultPath "C:\Users\JouwNaam\Obsidian\MijnVault"
.EXAMPLE
    .\ObsidianAttachmentCleaner.ps1 -VaultPath "D:\Notities" -Delete -WhatIf
.EXAMPLE
    .\ObsidianAttachmentCleaner.ps1 -VaultPath "D:\Notities" -IncludePatterns "*.png,*.jpg,*.pdf"
.LINK
    https://github.com/Dominiekge/DG
#>

[CmdletBinding()]
param (
    [Parameter(Mandatory=$false)]
    [string]$VaultPath,
    
    [Parameter(Mandatory=$false)]
    [string]$IncludePatterns = "*.png,*.jpg,*.jpeg,*.gif,*.pdf,*.webp,*.svg,*.mp4,*.mov,*.mp3,*.wav,*.heic,*.heif",
    
    [Parameter(Mandatory=$false)]
    [string]$ExcludePatterns = "",
    
    [Parameter(Mandatory=$false)]
    [switch]$Delete,
    
    [Parameter(Mandatory=$false)]
    [switch]$WhatIf
)

# Region: Functions

function Write-Header {
    param([string]$Message)
    Write-Host "`n$Message" -ForegroundColor Cyan
}

function Write-Success {
    param([string]$Message)
    Write-Host "[✓] $Message" -ForegroundColor Green
}

function Write-Warning {
    param([string]$Message)
    Write-Host "[!] $Message" -ForegroundColor Yellow
}

function Write-ErrorMsg {
    param([string]$Message)
    Write-Host "[✗] $Message" -ForegroundColor Red
}

function Write-Info {
    param([string]$Message)
    Write-Host "[i] $Message" -ForegroundColor White
}

function Escape-Regex {
    param([string]$String)
    # Escape speciale regex karakters
    return $String -replace '([\\\.$^{}()\|[\]\+\?])', '\$1'
}

function Get-FileName {
    param([string]$FilePath)
    return [System.IO.Path]::GetFileName($FilePath)
}

function Get-FileNameWithoutExt {
    param([string]$FilePath)
    return [System.IO.Path]::GetFileNameWithoutExtension($FilePath)
}

function Get-RelativePath {
    param([string]$FilePath, [string]$BasePath)
    try {
        $uri1 = [Uri]$FilePath
        $uri2 = [Uri]$BasePath
        $relativeUri = $uri2.MakeRelativeUri($uri1)
        return $relativeUri.ToString().Replace('/', '\')
    } catch {
        return $FilePath
    }
}

function Find-AllMarkdownFiles {
    param([string]$VaultPath)
    
    $markdownFiles = @()
    
    # Zoek alle .md bestanden
    $allFiles = Get-ChildItem -Path $VaultPath -Recurse -File -Force -ErrorAction SilentlyContinue |
                Where-Object { $_.Extension -eq ".md" -and $_.FullName -notlike "*\node_modules*" -and $_.FullName -notlike "*\.git*" -and $_.FullName -notlike "*\.obsidian*" }
    
    foreach ($file in $allFiles) {
        $markdownFiles += $file.FullName
    }
    
    return $markdownFiles
}

function Find-AllAttachments {
    param(
        [string]$VaultPath,
        [string[]]$IncludePatterns,
        [string[]]$ExcludePatterns
    )
    
    $allAttachments = @()
    
    foreach ($pattern in $IncludePatterns) {
        try {
            $files = Get-ChildItem -Path $VaultPath -Recurse -File -Force -ErrorAction SilentlyContinue |
                     Where-Object { 
                         $_.FullName -like $pattern -and 
                         $_.FullName -notlike "*\node_modules*" -and 
                         $_.FullName -notlike "*\.git*" -and 
                         $_.FullName -notlike "*\.obsidian*"
                     }
            $allAttachments += $files.FullName
        } catch {
            Write-Warning "Fout bij zoeken naar patronen $pattern : $_"
        }
    }
    
    # Filter exclude patronen
    if ($ExcludePatterns -and $ExcludePatterns.Length -gt 0) {
        $filteredAttachments = @()
        foreach ($file in $allAttachments) {
            $shouldExclude = $false
            foreach ($excludePattern in $ExcludePatterns) {
                if ($file -like "*$excludePattern*" -or [System.IO.Path]::GetFileName($file) -like "*$excludePattern*") {
                    $shouldExclude = $true
                    break
                }
            }
            if (-not $shouldExclude) {
                $filteredAttachments += $file
            }
        }
        return $filteredAttachments
    }
    
    return $allAttachments
}

function Is-AttachmentUsed {
    param(
        [string]$AttachmentPath,
        [string[]]$MarkdownFiles
    )
    
    $fileName = Get-FileName $AttachmentPath
    $fileNameWithoutExt = Get-FileNameWithoutExt $AttachmentPath
    
    $escapedFileName = Escape-Regex $fileName
    $escapedFileNameWithoutExt = Escape-Regex $fileNameWithoutExt
    
    foreach ($mdFile in $MarkdownFiles) {
        try {
            $content = Get-Content -Path $mdFile -Raw -ErrorAction SilentlyContinue
            
            if (-not $content) { continue }
            
            # Check 1: Exacte match van de volledige bestandsnaam
            if ($content -like "*$fileName*") {
                return $true
            }
            
            # Check 2: Match zonder extensie (voor [[wiki-links]])
            # Obsidian wiki-links: [[Negenvlaksmodel 1.png]] of [[Negenvlaksmodel 1]]
            $wikiLinkPattern = "\\[\\[\\s*$escapedFileNameWithoutExt\\.[a-zA-Z0-9]+\\s*\\]\\]|" +
                               "\\[\\[\\s*$escapedFileNameWithoutExt\\s*\\]\\]"
            if ($content -match $wikiLinkPattern) {
                return $true
            }
            
            # Check 3: Markdown links: ![alt](Negenvlaksmodel 1.png) of [text](Negenvlaksmodel 1.png)
            if ($content -match "\\([^)]*$escapedFileName\\)") {
                return $true
            }
            
            # Check 4: HTML-style links: <img src="Negenvlaksmodel 1.png">
            if ($content -match "<[^>]*$escapedFileName[^>]*>") {
                return $true
            }
            
            # Check 5: YAML frontmatter
            if ($content -match "$escapedFileNameWithoutExt\\s*:.*") {
                return $true
            }
            
        } catch {
            Write-Warning "Fout bij lezen van $mdFile : $_"
        }
    }
    
    return $false
}

function Scan-Vault {
    param(
        [string]$VaultPath,
        [string[]]$IncludePatterns,
        [string[]]$ExcludePatterns
    )
    
    Write-Info "Scannen van vault: $VaultPath"
    
    $markdownFiles = Find-AllMarkdownFiles -VaultPath $VaultPath
    Write-Info "Gevonden $($markdownFiles.Count) markdown bestanden"
    
    $attachmentFiles = Find-AllAttachments -VaultPath $VaultPath -IncludePatterns $IncludePatterns -ExcludePatterns $ExcludePatterns
    Write-Info "Gevonden $($attachmentFiles.Count) attachment bestanden"
    
    $results = @()
    $usedCount = 0
    $unusedCount = 0
    
    $total = $attachmentFiles.Count
    $current = 0
    
    foreach ($attachment in $attachmentFiles) {
        $current++
        $relativePath = Get-RelativePath $attachment $VaultPath
        
        # Voortgang tonen
        $progress = [math]::Round(($current / $total) * 100, 1)
        Write-Progress -Activity "Scannen attachments..." -Status "$progress% - Controleer: $relativePath" -PercentComplete $progress
        
        $isUsed = Is-AttachmentUsed -AttachmentPath $attachment -MarkdownFiles $markdownFiles
        
        $results += [PSCustomObject]@{
            Path = $relativePath
            FullPath = $attachment
            Used = $isUsed
        }
        
        if ($isUsed) { $usedCount++ }
        else { $unusedCount++ }
    }
    
    Write-Progress -Activity "Scannen attachments..." -Completed
    
    return @{
        Total = $total
        Used = $usedCount
        Unused = $unusedCount
        Results = $results
        MarkdownFiles = $markdownFiles.Count
    }
}

function Show-Results {
    param(
        [object]$ScanResult,
        [string]$VaultPath
    )
    
    Write-Header "`n============================================================"
    Write-Header "                SCAN RESULTATEN"
    Write-Header "============================================================"
    Write-Host "Vault pad: $VaultPath"
    Write-Host ""
    Write-Host "Samenvatting:"
    Write-Host "  Totaal attachments: $($ScanResult.Total)"
    Write-Success "  Gebruikte attachments: $($ScanResult.Used)"
    Write-ErrorMsg "  Ongebruikte attachments: $($ScanResult.Unused)"
    Write-Host "  Markdown bestanden: $($ScanResult.MarkdownFiles)"
    Write-Header "============================================================"
    
    if ($ScanResult.Unused -eq 0) {
        Write-Success "Alle attachments worden gebruikt! Er is niets om te verwijderen."
        return
    }
    
    Write-Host "`nOngebruikte attachments:"
    Write-Host "----------------------------"
    
    $unusedFiles = $ScanResult.Results | Where-Object { -not $_.Used }
    foreach ($file in $unusedFiles) {
        Write-ErrorMsg "  ✗ $($file.Path)"
    }
    
    Write-Host ""
    if (-not $WhatIf -and -not $Delete) {
        Write-Warning "Gebruik -Delete om de ongebruikte attachments te verwijderen"
        Write-Warning "Gebruik -WhatIf om te zien wat er zou gebeuren zonder te verwijderen"
    }
}

function Delete-Unused {
    param(
        [object[]]$FilesToDelete,
        [switch]$WhatIf
    )
    
    $deletedCount = 0
    $errors = @()
    
    Write-Header "`n============================================================"
    Write-Header "                VERWIJDEREN"
    Write-Header "============================================================"
    
    if ($WhatIf) {
        Write-Warning "Dry-run modus: Geen bestanden worden daadwerkelijk verwijderd"
    }
    
    $total = $FilesToDelete.Count
    $current = 0
    
    foreach ($file in $FilesToDelete) {
        $current++
        $progress = [math]::Round(($current / $total) * 100, 1)
        Write-Progress -Activity "Verwijderen..." -Status "$progress% - $($file.Path)" -PercentComplete $progress
        
        if (-not $WhatIf) {
            try {
                Remove-Item -Path $file.FullPath -Force -ErrorAction Stop
                $deletedCount++
                Write-Success "  ✓ Verwijderd: $($file.Path)"
            } catch {
                $errors += [PSCustomObject]@{
                    Path = $file.Path
                    Error = $_.Exception.Message
                }
                Write-ErrorMsg "  ✗ Fout bij verwijderen van $($file.Path): $($_.Exception.Message)"
            }
        } else {
            Write-Host "  [DRY-RUN] Verwijderen: $($file.Path)" -ForegroundColor Yellow
            $deletedCount++
        }
    }
    
    Write-Progress -Activity "Verwijderen..." -Completed
    
    Write-Host ""
    if ($WhatIf) {
        Write-Warning "Dry-run: $deletedCount bestanden zouden worden verwijderd"
    } else {
        Write-Success "Succes: $deletedCount van $total ongebruikte attachments verwijderd"
    }
    
    if ($errors.Count -gt 0) {
        Write-ErrorMsg "$($errors.Count) bestanden konden niet worden verwijderd:"
        foreach ($error in $errors) {
            Write-ErrorMsg "  - $($error.Path): $($error.Error)"
        }
    }
}

# EndRegion

# Main script

# Check PowerShell versie
if ($PSVersionTable.PSVersion.Major -lt 5) {
    Write-ErrorMsg "PowerShell 5.0 of hoger is vereist. Je hebt versie $($PSVersionTable.PSVersion)"
    exit 1
}

Write-Header "============================================================"
Write-Header "     Obsidian Attachment Cleaner (PowerShell versie)"
Write-Header "============================================================"

# Parse include patterns
$includePatternsArray = $IncludePatterns -split ',' | Where-Object { $_ -ne "" } | ForEach-Object { $_.Trim() }

# Parse exclude patterns
$excludePatternsArray = if ($ExcludePatterns -and $ExcludePatterns -ne "") {
    $ExcludePatterns -split ',' | Where-Object { $_ -ne "" } | ForEach-Object { $_.Trim() }
} else {
    @()
}

# Vault pad opvragen als niet opgegeven
if (-not $VaultPath -or $VaultPath -eq "") {
    Write-Host "`nVoer het pad naar je Obsidian vault in:" -ForegroundColor Cyan
    Write-Host "Bijv: C:\\Users\\JouwNaam\\Obsidian\\MijnVault" -ForegroundColor Gray
    $VaultPath = Read-Host "Vault pad"
    
    if (-not $VaultPath -or $VaultPath -eq "") {
        Write-ErrorMsg "Geen vault pad opgegeven"
        exit 1
    }
}

# Controleer of pad bestaat
if (-not (Test-Path -Path $VaultPath -PathType Container)) {
    Write-ErrorMsg "Het opgegeven pad bestaat niet of is geen map: $VaultPath"
    exit 1
}

# Normaliseer pad
$VaultPath = Resolve-Path -Path $VaultPath | Select-Object -ExpandProperty Path

# Toon instellingen
Write-Info "Vault pad: $VaultPath"
Write-Info "Include patronen: $($includePatternsArray -join ', ')"
if ($excludePatternsArray.Count -gt 0) {
    Write-Info "Exclude patronen: $($excludePatternsArray -join ', ')"
}
Write-Host ""

# Scan vault
try {
    $scanResult = Scan-Vault -VaultPath $VaultPath -IncludePatterns $includePatternsArray -ExcludePatterns $excludePatternsArray
    
    # Toon resultaten
    Show-Results -ScanResult $scanResult -VaultPath $VaultPath
    
    # Verwijderen als gevraagd
    if ($Delete -or $WhatIf) {
        $filesToDelete = $scanResult.Results | Where-Object { -not $_.Used }
        
        if ($filesToDelete.Count -eq 0) {
            Write-Success "Niets om te verwijderen - alle attachments worden gebruikt"
            exit 0
        }
        
        if (-not $WhatIf) {
            # Bevestiging vragen
            Write-Host "`n" -ForegroundColor Red
            Write-ErrorMsg "LET OP: Je staat op het punt om $($filesToDelete.Count) ongebruikte attachments PERMANENT te verwijderen!"
            Write-ErrorMsg "Deze actie kan niet ongedaan worden gemaakt."
            Write-Host ""
            $confirm = Read-Host "Weet je het zeker? Typ 'JA' om door te gaan of 'NEE' om te annuleren"
            
            if ($confirm -ne "JA" -and $confirm -ne "ja") {
                Write-Warning "Geannuleerd"
                exit 0
            }
        }
        
        Delete-Unused -FilesToDelete $filesToDelete -WhatIf:$WhatIf
    }
    
} catch {
    Write-ErrorMsg "Fout tijdens scannen: $_"
    exit 1
}

Write-Host "`nKlaar!" -ForegroundColor Green
