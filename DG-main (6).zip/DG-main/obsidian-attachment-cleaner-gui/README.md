# Obsidian Attachment Cleaner GUI

Een Windows applicatie om ongebruikte attachments (afbeeldingen, PDF's, etc.) in Obsidian vaults op te sporen en optioneel te verwijderen.

## 🚀 **Snelle Start (ZONDER Node.js!)**

Je hebt **GEEN Node.js nodig**! Gebruik een van deze methoden:

### **Optie 1: PowerShell Script (Aanbevolen)**

1. Download het bestand: **[ObsidianAttachmentCleaner.ps1](ObsidianAttachmentCleaner.ps1)**
2. **Rechtsklik** op het bestand en selecteer **"Uitvoeren met PowerShell"**
   OF
   Open PowerShell en voer uit:
   ```powershell
   .\ObsidianAttachmentCleaner.ps1
   ```

### **Optie 2: Batch File (Eenvoudig)**

1. Download: **[run-powershell.bat](run-powershell.bat)**
2. **Dubbelklik** op het batch bestand

### **Optie 3: VBScript GUI (Geen PowerShell venster)**

1. Download: **[ObsidianAttachmentCleaner.vbs](ObsidianAttachmentCleaner.vbs)**
2. **Dubbelklik** op het VBS bestand

---

## 📋 **Overzicht**

Deze applicatie helpt je om ongebruikte afbeeldingen en PDF's in je Obsidian vault te vinden en te verwijderen. De tool zoekt naar:

- ✅ **Platte tekst** - Bijv: `Negenvlaksmodel 1.png`
- ✅ **Wiki-links** - Bijv: `[[Logo Obsidian.png]]` of `[[iAMPpro-model.pdf]]`
- ✅ **Markdown links** - Bijv: `![alt](afbeelding.png)` of `[text](document.pdf)`
- ✅ **HTML links** - Bijv: `<img src="afbeelding.png">`
- ✅ **YAML frontmatter** - Bijv: `cover: afbeelding.jpg`

## 🎯 **Functies**

### **PowerShell Versie** (`ObsidianAttachmentCleaner.ps1`)
- ⚡ **Snel** - Gebruikt PowerShell voor optimale prestaties
- 🎨 **Kleurrijke output** - Duidelijke kleurcodes in de console
- 📊 **Voortgangsindicatie** - Ziet hoever de scan is
- 🗑️ **Selectieve verwijdering** - Verwijder alleen wat je wilt
- 🔍 **Flexibele filters** - Pas aan welke bestanden worden gescand

### **VBScript Versie** (`ObsidianAttachmentCleaner.vbs`)
- 🪟 **GUI dialoog** - Makkelijk vault pad selecteren
- 💻 **Geen console venster** - Netjes geïntegreerd
- 📁 **Bestandsselectie** - Blader door je mappen

## 📖 **Gebruik**

### **Basis Gebruik**

Voer het script uit en volg de instructies:

```powershell
# Scan je vault (alleen tonen)
.\ObsidianAttachmentCleaner.ps1 -VaultPath "C:\Users\JouwNaam\Obsidian\MijnVault"

# Dry-run: toon wat verwijderd zou worden
.\ObsidianAttachmentCleaner.ps1 -VaultPath "C:\Users\JouwNaam\Obsidian\MijnVault" -WhatIf

# Daadwerkelijk verwijderen
.\ObsidianAttachmentCleaner.ps1 -VaultPath "C:\Users\JouwNaam\Obsidian\MijnVault" -Delete
```

### **Geavanceerde Opties**

```powershell
# Specifieke extensies scannen
.\ObsidianAttachmentCleaner.ps1 -VaultPath "D:\Notities" -IncludePatterns "*.png,*.jpg,*.pdf"

# Bestanden uitsluiten
.\ObsidianAttachmentCleaner.ps1 -VaultPath "D:\Notities" -ExcludePatterns "screenshot,temp,backup"

# Combinatie
.\ObsidianAttachmentCleaner.ps1 -VaultPath "D:\Notities" -IncludePatterns "*.png,*.jpg" -ExcludePatterns "temp" -WhatIf
```

### **Interactieve Modus**

Voer het script uit **zonder parameters** om interactief het vault pad in te voeren:

```powershell
.\ObsidianAttachmentCleaner.ps1
```

Het script zal je dan vragen om het pad in te voeren.

## 🎬 **Stap-voor-Stap Handleiding**

### **Stap 1: Script downloaden**

1. Download **ObsidianAttachmentCleaner.ps1** van deze repository
2. Sla het bestand op in een map naar keuze (bijv: `C:\Tools\ObsidianCleaner`)

### **Stap 2: Script uitvoeren**

**Methode A: Rechtsklik**
- Rechtsklik op `ObsidianAttachmentCleaner.ps1`
- Selecteer **"Uitvoeren met PowerShell"**

**Methode B: PowerShell**
- Open PowerShell
- Navigeer naar de map: `cd C:\Tools\ObsidianCleaner`
- Voer uit: ` .\ObsidianAttachmentCleaner.ps1`

**Methode C: Batch bestand**
- Dubbelklik op `run-powershell.bat`

### **Stap 3: Vault pad selecteren**

Je kunt:
1. **Handmatig typen** - Voer het volledige pad in
2. **Kopiëren en plakken** - Kopieer het pad uit Verkenner
3. **Bladeren** (in VBScript versie) - Gebruik de bladeren dialoog

Voorbeeld paden:
- `C:\Users\JouwNaam\Obsidian\MijnVault`
- `D:\Documents\Obsidian\Notities`
- `\\NAS\Obsidian\Vault`

### **Stap 4: Scan uitvoeren**

Het script zal:
1. Alle `.md` bestanden scannen
2. Alle attachments vinden (afbeeldingen, PDF's, etc.)
3. Controleren welke attachments worden gebruikt
4. Resultaten tonen

### **Stap 5: Ongebruikte bestanden verwijderen (optioneel)**

Als er ongebruikte bestanden zijn gevonden:
- Gebruik `-WhatIf` om te zien wat er zou worden verwijderd
- Gebruik `-Delete` om daadwerkelijk te verwijderen
- Je krijgt een **bevestigingsvraag** voordat er iets wordt verwijderd

## ⚙️ **Opties**

| Optie | Beschrijving | Voorbeeld |
|-------|-------------|-----------|
| `-VaultPath` | Pad naar de Obsidian vault | `-VaultPath "C:\Notities"` |
| `-IncludePatterns` | Patronen voor te scannen bestanden | `-IncludePatterns "*.png,*.jpg"` |
| `-ExcludePatterns` | Patronen om uit te sluiten | `-ExcludePatterns "screenshot,temp"` |
| `-Delete` | Verwijder ongebruikte bestanden | `-Delete` |
| `-WhatIf` | Toon wat er zou gebeuren | `-WhatIf` |

### **Standaard Inclusie Patronen**

Het script scant standaard naar:
- `*.png`, `*.jpg`, `*.jpeg`, `*.gif`, `*.webp`, `*.svg` (afbeeldingen)
- `*.pdf` (PDF documenten)
- `*.mp4`, `*.mov` (video)
- `*.mp3`, `*.wav` (audio)
- `*.heic`, `*.heif` (iOS afbeeldingen)

## ⚠️ **Veiligheid**

### **Belangrijke Waarschuwingen**

1. **📦 Maak een backup** - Voordat je bestanden verwijdert, maak een backup van je vault!
2. **🔍 Dry-run eerst** - Gebruik `-WhatIf` om te zien wat er verwijderd zal worden
3. **❓ Bevestiging** - Je moet expliciet bevestigen voordat er iets wordt verwijderd
4. **🗑️ Permanent** - Verwijderde bestanden zijn **definitief weg**

### **Wat wordt NIET gescand**

- Bestanden in `node_modules/` mappen
- Bestanden in `.git/` mappen
- Bestanden in `.obsidian/` mappen
- Bestanden die niet matchen met de inclusie patronen

## 🛠️ **Vereisten**

### **PowerShell Script**
- ✅ **Windows 7 of hoger**
- ✅ **PowerShell 5.0 of hoger** (standaard op Windows 10/11)
- ❌ **Geen Node.js nodig!**

### **VBScript**
- ✅ **Windows 7 of hoger**
- ✅ **PowerShell 5.0 of hoger** (voor de achtergrond taken)

### **PowerShell versie controleren**

Open PowerShell en voer uit:
```powershell
$PSVersionTable.PSVersion
```

Als de Major versie **5 of hoger** is, ben je goed!

## 🐛 **Problemen Oplossen**

### **"PowerShell is niet beschikbaar"**

- **Oplossing**: Installeer PowerShell van [https://aka.ms/windowspowershell](https://aka.ms/windowspowershell)

### **"Script kan niet worden uitgevoerd"**

Deze fout komt door het **Execution Policy** in PowerShell:

**Oplossing 1: Tijdelijk toestaan**
```powershell
powershell -ExecutionPolicy Bypass -File .\ObsidianAttachmentCleaner.ps1
```

**Oplossing 2: Execution Policy wijzigen** (als administrator)
```powershell
Set-ExecutionPolicy RemoteSigned -Scope CurrentUser
```

**Oplossing 3: Gebruik het batch bestand**
- Het batch bestand gebruikt al `-ExecutionPolicy Bypass`

### **"Geen markdown bestanden gevonden"**

- Controleer of het vault pad correct is
- Zorg dat er daadwerkelijk `.md` bestanden in de vault zitten
- Controleer of de map niet leeg is

### **"Geen attachments gevonden"**

- Controleer of de inclusie patronen correct zijn
- Zorg dat de attachments in de vault map zitten
- Probeer breder patronen: `-IncludePatterns "*"`

### **"Bestand wordt als ongebruikt gemarkeerd maar wordt wel gebruikt"**

- Controleer of de exacte bestandsnaam (inclusief extensie) in een `.md` bestand staat
- Controleer op typefouten in de bestandsnaam
- PowerShell is **gevoelig voor hoofdletters**!

## 📊 **Voorbeeld Output**

```
============================================================
     Obsidian Attachment Cleaner (PowerShell versie)
============================================================

Vault pad: C:\Users\JouwNaam\Obsidian\MijnVault
Include patronen: *.png, *.jpg, *.jpeg, *.gif, *.pdf, *.webp, *.svg, *.mp4, *.mov, *.mp3, *.wav

Scannen van vault: C:\Users\JouwNaam\Obsidian\MijnVault
Gevonden 42 markdown bestanden
Gevonden 156 attachment bestanden

============================================================
                SCAN RESULTATEN
============================================================
Vault pad: C:\Users\JouwNaam\Obsidian\MijnVault

Samenvatting:
  Totaal attachments: 156
  Gebruikte attachments: 142
  Ongebruikte attachments: 14
  Markdown bestanden: 42
============================================================

Ongebruikte attachments:
----------------------------
  ✗ Afbeeldingen/Ongebruikt.png
  ✗ Afbeeldingen/Old-screenshot.jpg
  ✗ PDFs/Onnodig-document.pdf

Gebruik -Delete om de ongebruikte attachments te verwijderen
Gebruik -WhatIf om te zien wat er zou gebeuren zonder te verwijderen
```

## 🤝 **Bijdragen**

Pull requests zijn welkom! Voor grote wijzigingen:

1. Fork de repository
2. Maak een feature branch (`git checkout -b feature/amazing-feature`)
3. Commit je wijzigingen (`git commit -m 'Voeg amazing feature toe'`)
4. Push naar de branch (`git push origin feature/amazing-feature`)
5. Open een Pull Request

## 📜 **Licentie**

Dit project is gelicenseerd onder de **MIT License**.

## 📧 **Contact**

Voor vragen, suggesties of problemen:
- GitHub Repository: [https://github.com/Dominiekge/DG](https://github.com/Dominiekge/DG)
- Open een Issue voor bug reports
- Open een Pull Request voor bijdragen

---

Gemaakt met ❤️ voor de Obsidian community

**Geen Node.js nodig!** 🎉
