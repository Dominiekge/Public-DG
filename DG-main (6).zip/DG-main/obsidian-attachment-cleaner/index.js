#!/usr/bin/env node

/**
 * Obsidian Attachment Cleaner
 * 
 * Een tool om ongebruikte attachments (afbeeldingen, PDF's, etc.) in Obsidian vaults
 * op te sporen en optioneel te verwijderen.
 * 
 * Gebruik: node index.js <vault-path> [options]
 * 
 * Voorbeeld: node index.js /pad/naar/mijn/vault --dry-run
 */

const fs = require('fs-extra');
const path = require('path');
const glob = require('glob');
const chalk = require('chalk');
const { program } = require('commander');

// Configureer commander
program
  .name('obsidian-attachment-cleaner')
  .description('Tool om ongebruikte attachments in Obsidian vaults op te sporen en te verwijderen')
  .version('1.0.0')
  .argument('<vault-path>', 'Pad naar de Obsidian vault')
  .option('-d, --dry-run', 'Alleen tonen welke bestanden verwijderd zouden worden, niet daadwerkelijk verwijderen')
  .option('-i, --include <patterns>', 'Patronen voor attachment bestanden (gescheiden door komma)', '*.png,*.jpg,*.jpeg,*.gif,*.pdf,*.webp,*.svg,*.mp4,*.mov,*.mp3,*.wav')
  .option('-e, --exclude <patterns>', 'Patronen om uit te sluiten (gescheiden door komma)')
  .option('-q, --quiet', 'Minder output tonen')
  .option('-v, --verbose', 'Meer details tonen')
  .option('--delete', 'Daadwerkelijk bestanden verwijderen (zonder --delete wordt alleen getoond)')
  .parse(process.argv);

const options = program.opts();
const vaultPath = program.args[0];

// Valideer input
if (!vaultPath || !fs.existsSync(vaultPath)) {
  console.error(chalk.red('Fout: Ongeldig vault pad'));
  console.error(`   Pad: ${vaultPath}`);
  process.exit(1);
}

// Normaliseer het vault pad
const normalizedVaultPath = path.resolve(vaultPath);

// Standaard attachment extensies
const DEFAULT_ATTACHMENT_PATTERNS = ['*.png', '*.jpg', '*.jpeg', '*.gif', '*.pdf', '*.webp', '*.svg', '*.mp4', '*.mov', '*.mp3', '*.wav', '*.heic', '*.heif'];

// Haal include patronen op
let includePatterns = DEFAULT_ATTACHMENT_PATTERNS;
if (options.include) {
  includePatterns = options.include.split(',').map(p => p.trim());
}

// Haal exclude patronen op
let excludePatterns = [];
if (options.exclude) {
  excludePatterns = options.exclude.split(',').map(p => p.trim());
}

// Globale variabelen
let totalAttachments = 0;
let usedAttachmentsCount = 0;
let unusedAttachmentsCount = 0;
let deletedCount = 0;

/**
 * Log berichten met verschillende niveaus
 */
function log(message, level = 'info') {
  if (options.quiet && level === 'debug') return;
  
  switch (level) {
    case 'error':
      console.log(chalk.red(`[ERROR] ${message}`));
      break;
    case 'warn':
      console.log(chalk.yellow(`[WARN] ${message}`));
      break;
    case 'success':
      console.log(chalk.green(`[SUCCESS] ${message}`));
      break;
    case 'debug':
      if (options.verbose) {
        console.log(chalk.gray(`[DEBUG] ${message}`));
      }
      break;
    default:
      console.log(chalk.white(`[INFO] ${message}`));
  }
}

/**
 * Vind alle markdown bestanden in de vault
 */
function findAllMarkdownFiles(vaultPath) {
  log('Zoeken naar markdown bestanden...', 'debug');
  
  const markdownFiles = glob.sync(path.join(vaultPath, '**', '*.md'), {
    ignore: ['**/node_modules/**', '**/.git/**', '**/.obsidian/**'],
    nodir: true
  });
  
  log(`Gevonden ${markdownFiles.length} markdown bestanden`, 'debug');
  return markdownFiles;
}

/**
 * Vind alle attachment bestanden in de vault
 */
function findAllAttachments(vaultPath, includePatterns, excludePatterns) {
  log('Zoeken naar attachment bestanden...', 'debug');
  
  const allAttachments = [];
  
  for (const pattern of includePatterns) {
    const files = glob.sync(path.join(vaultPath, '**', pattern), {
      ignore: ['**/node_modules/**', '**/.git/**', '**/.obsidian/**'],
      nodir: true
    });
    allAttachments.push(...files);
  }
  
  // Filter exclude patronen
  if (excludePatterns.length > 0) {
    const filteredAttachments = [];
    for (const file of allAttachments) {
      let shouldExclude = false;
      for (const excludePattern of excludePatterns) {
        if (file.includes(excludePattern)) {
          shouldExclude = true;
          break;
        }
      }
      if (!shouldExclude) {
        filteredAttachments.push(file);
      }
    }
    return filteredAttachments;
  }
  
  log(`Gevonden ${allAttachments.length} attachment bestanden`, 'debug');
  return allAttachments;
}

/**
 * Haal de bestandsnaam uit een pad
 */
function getFileName(filePath) {
  return path.basename(filePath);
}

/**
 * Haal de bestandsnaam ZONDER extensie uit een pad
 */
function getFileNameWithoutExt(filePath) {
  const baseName = path.basename(filePath);
  return baseName.replace(path.extname(baseName), '');
}

/**
 * Escape speciale regex karakters
 */
function escapeRegExp(string) {
  return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/**
 * Controleer of een attachment wordt gebruikt in markdown bestanden
 * Zoekt naar de exacte bestandsnaam (inclusief extensie) in alle .md bestanden
 */
function isAttachmentUsed(attachmentPath, markdownFiles) {
  const fileName = getFileName(attachmentPath);
  const fileNameWithoutExt = getFileNameWithoutExt(attachmentPath);
  
  // Escape speciale regex karakters in de bestandsnaam
  const escapedFileName = escapeRegExp(fileName);
  const escapedFileNameWithoutExt = escapeRegExp(fileNameWithoutExt);
  
  // Zoek naar exacte matches in alle markdown bestanden
  for (const mdFile of markdownFiles) {
    try {
      const content = fs.readFileSync(mdFile, 'utf8');
      
      // Check 1: Exacte match van de volledige bestandsnaam
      // Bijv: "Negenvlaksmodel 1.png" staat precies zo in het bestand
      if (content.includes(fileName)) {
        log(`  Gebruikt in: ${path.relative(normalizedVaultPath, mdFile)}`, 'debug');
        return true;
      }
      
      // Check 2: Match zonder extensie (voor [[wiki-links]])
      // Obsidian wiki-links: [[Negenvlaksmodel 1.png]] of [[Negenvlaksmodel 1]]
      const wikiLinkPattern = new RegExp("\\[\\[\\s*" + escapedFileNameWithoutExt + "\\.[a-zA-Z0-9]+\\s*\\]\\]|" +
                                          "\\[\\[\\s*" + escapedFileNameWithoutExt + "\\s*\\]\\]", 'i');
      if (wikiLinkPattern.test(content)) {
        log(`  Gebruikt als wiki-link in: ${path.relative(normalizedVaultPath, mdFile)}`, 'debug');
        return true;
      }
      
      // Check 3: Markdown links: ![alt](Negenvlaksmodel 1.png) of [text](Negenvlaksmodel 1.png)
      const mdLinkPattern = new RegExp("\\([^)]*" + escapedFileName + "\\)", 'i');
      if (mdLinkPattern.test(content)) {
        log(`  Gebruikt als markdown link in: ${path.relative(normalizedVaultPath, mdFile)}`, 'debug');
        return true;
      }
      
      // Check 4: HTML-style links: <img src="Negenvlaksmodel 1.png">
      const htmlLinkPattern = new RegExp("<[^>]*" + escapedFileName + "[^>]*>", 'i');
      if (htmlLinkPattern.test(content)) {
        log(`  Gebruikt als HTML link in: ${path.relative(normalizedVaultPath, mdFile)}`, 'debug');
        return true;
      }
      
      // Check 5: URL-encoded bestandsnamen
      const urlEncodedFileName = encodeURIComponent(fileName);
      if (content.includes(urlEncodedFileName)) {
        log(`  Gebruikt als URL-encoded in: ${path.relative(normalizedVaultPath, mdFile)}`, 'debug');
        return true;
      }
      
    } catch (error) {
      log(`Fout bij lezen van ${mdFile}: ${error.message}`, 'warn');
    }
  }
  
  return false;
}

/**
 * Hoofd functie
 */
async function main() {
  log('Start Obsidian Attachment Cleaner');
  log(`Vault pad: ${chalk.cyan(normalizedVaultPath)}`);
  log(`Include patronen: ${chalk.cyan(includePatterns.join(', '))}`);
  if (excludePatterns.length > 0) {
    log(`Exclude patronen: ${chalk.cyan(excludePatterns.join(', '))}`);
  }
  log('');
  
  // Vind alle markdown bestanden
  const markdownFiles = findAllMarkdownFiles(normalizedVaultPath);
  
  if (markdownFiles.length === 0) {
    log('Geen markdown bestanden gevonden in de vault!', 'warn');
    return;
  }
  
  // Vind alle attachment bestanden
  const attachmentFiles = findAllAttachments(normalizedVaultPath, includePatterns, excludePatterns);
  
  if (attachmentFiles.length === 0) {
    log('Geen attachment bestanden gevonden die matchen met de patronen', 'success');
    return;
  }
  
  log(`Gevonden ${attachmentFiles.length} attachment bestanden`);
  log(`Gevonden ${markdownFiles.length} markdown bestanden`);
  log('');
  
  // Controleer welke attachments worden gebruikt
  const unusedAttachments = [];
  const usedAttachmentsList = [];
  
  for (const attachment of attachmentFiles) {
    totalAttachments++;
    const relativePath = path.relative(normalizedVaultPath, attachment);
    
    process.stdout.write(`Controleer: ${chalk.cyan(relativePath)}... `);
    
    const isUsed = isAttachmentUsed(attachment, markdownFiles);
    
    if (isUsed) {
      usedAttachmentsCount++;
      usedAttachmentsList.push(attachment);
      console.log(chalk.green('Gebruikt'));
    } else {
      unusedAttachmentsCount++;
      unusedAttachments.push(attachment);
      console.log(chalk.red('Niet gebruikt'));
    }
  }
  
  log('');
  console.log('='.repeat(60));
  console.log('Samenvatting:');
  console.log(`  Totaal attachments: ${chalk.cyan(totalAttachments)}`);
  console.log(`  Gebruikte attachments: ${chalk.green(usedAttachmentsCount)}`);
  console.log(`  Ongebruikte attachments: ${chalk.red(unusedAttachmentsCount)}`);
  console.log('='.repeat(60));
  
  if (unusedAttachments.length === 0) {
    log('Alle attachments worden gebruikt!', 'success');
    return;
  }
  
  console.log('');
  console.log('Ongebruikte attachments:');
  for (const attachment of unusedAttachments) {
    console.log(`  ${chalk.red('X')} ${path.relative(normalizedVaultPath, attachment)}`);
  }
  
  console.log('');
  
  // Vraag om bevestiging als --delete is opgegeven
  if (options.delete) {
    if (options.dryRun) {
      log('--dry-run is actief, geen bestanden verwijderd', 'warn');
    } else {
      log('Let op: De volgende bestanden zullen worden verwijderd!', 'warn');
      
      for (const attachment of unusedAttachments) {
        const relativePath = path.relative(normalizedVaultPath, attachment);
        try {
          await fs.remove(attachment);
          deletedCount++;
          console.log(`  ${chalk.green('Verwijderd')} ${relativePath}`);
        } catch (error) {
          console.log(`  ${chalk.red('Fout')} bij verwijderen van ${relativePath}: ${error.message}`);
        }
      }
      
      console.log('');
      console.log(`Succes: ${deletedCount} van ${unusedAttachments.length} ongebruikte attachments verwijderd`, chalk.green(''));
    }
  } else {
    console.log('Gebruik --delete om de ongebruikte attachments daadwerkelijk te verwijderen');
  }
}

// Voer de hoofd functie uit
main().catch(error => {
  console.error(chalk.red(`Fout: ${error.message}`));
  process.exit(1);
});
