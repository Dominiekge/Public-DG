# Obsidian Attachment Cleaner

Een tool om ongebruikte attachments (afbeeldingen, PDF's, etc.) in Obsidian vaults op te sporen en optioneel te verwijderen.

## Probleem

De vorige versie van de attachment cleaner gooide te veel weg, inclusief afbeeldingen die wél werden gebruikt. Deze verbeterde versie zoekt simpelweg naar de **exacte bestandsnaam** van de attachment in alle markdown bestanden.

Bijvoorbeeld: als je een afbeelding hebt genaamd `"Negenvlaksmodel 1.png"` en deze naam komt ergens voor in een markdown bestand, wordt de attachment als **gebruikt** gemarkeerd.

## Functies

- ✅ Zoekt naar exacte bestandsnamen in markdown bestanden
- ✅ Ondersteunt Obsidian wiki-links: `[[Negenvlaksmodel 1.png]]` of `[[Negenvlaksmodel 1]]`
- ✅ Ondersteunt markdown links: `![alt](Negenvlaksmodel 1.png)` of `[text](Negenvlaksmodel 1.png)`
- ✅ Ondersteunt HTML-style links: `<img src="Negenvlaksmodel 1.png">`
- ✅ Dry-run modus om te zien wat verwijderd zou worden
- ✅ Flexibele include/exclude patronen
- ✅ Gedetailleerde logging

## Installatie

### Als npm package (aanbevolen)

```bash
npm install -g .
```

### Lokaal gebruik

```bash
cd obsidian-attachment-cleaner
npm install
node index.js /pad/naar/je/vault
```

## Gebruik

### Basis gebruik

```bash
# Alleen tonen welke attachments niet worden gebruikt
node index.js /pad/naar/je/vault

# Dry-run: toon wat verwijderd zou worden
node index.js /pad/naar/je/vault --dry-run

# Daadwerkelijk verwijderen (let op: dit is definitief!)
node index.js /pad/naar/je/vault --delete
```

### Geavanceerde opties

```bash
# Specifieke extensies opgeven
node index.js /pad/naar/je/vault --include "*.png,*.jpg,*.pdf"

# Extensies uitsluiten
node index.js /pad/naar/je/vault --exclude "screenshot,temp"

# Meer details tonen
node index.js /pad/naar/je/vault --verbose

# Minder output
node index.js /pad/naar/je/vault --quiet

# Combinatie
node index.js /pad/naar/je/vault --include "*.png,*.jpg" --exclude "temp" --dry-run --verbose
```

## Voorbeelden

### Voorbeeld 1: Alleen scannen

```bash
node index.js ~/Obsidian/Vault
```

Output:
```
[INFO] Start Obsidian Attachment Cleaner
[INFO] Vault pad: /home/user/Obsidian/Vault
[INFO] Include patronen: *.png,*.jpg,*.jpeg,*.gif,*.pdf,*.webp,*.svg,*.mp4,*.mov,*.mp3,*.wav

Controleer: Afbeeldingen/Negenvlaksmodel 1.png... ✓ Gebruikt
Controleer: Afbeeldingen/Ongebruikt.png... ✗ Niet gebruikt

============================================================
Samenvatting:
  Totaal attachments: 2
  Gebruikte attachments: 1
  Ongebruikte attachments: 1
============================================================

Ongebruikte attachments:
  ✗ Afbeeldingen/Ongebruikt.png

Gebruik --delete om de ongebruikte attachments daadwerkelijk te verwijderen
```

### Voorbeeld 2: Dry-run met verwijderen

```bash
node index.js ~/Obsidian/Vault --dry-run --delete
```

Output:
```
... (zelfde als hierboven)
⚠️  --dry-run is actief, geen bestanden verwijderd
```

### Voorbeeld 3: Daadwerkelijk verwijderen

```bash
node index.js ~/Obsidian/Vault --delete
```

Output:
```
... (scan resultaten)

⚠️  Let op: De volgende bestanden zullen worden verwijderd!
  ✓ Verwijderd: Afbeeldingen/Ongebruikt.png

✓ 1 van 1 ongebruikte attachments verwijderd
```

## Hoe het werkt

### Zoekstrategie

De tool doorzoekt alle markdown bestanden (`.md`) in de vault en zoekt naar:

1. **Exacte bestandsnaam** - Bijv: `Negenvlaksmodel 1.png`
2. **Wiki-links** - Bijv: `[[Negenvlaksmodel 1.png]]` of `[[Negenvlaksmodel 1]]`
3. **Markdown links** - Bijv: `![alt](Negenvlaksmodel 1.png)` of `[text](Negenvlaksmodel 1.png)`
4. **HTML links** - Bijv: `<img src="Negenvlaksmodel 1.png">`
5. **URL-encoded namen** - Bijv: `Negenvlaksmodel%201.png`

Als de bestandsnaam **ergens** in een markdown bestand voorkomt, wordt de attachment als **gebruikt** beschouwd.

### Standaard patronen

De tool zoekt standaard naar de volgende extensies:
- `*.png`
- `*.jpg`
- `*.jpeg`
- `*.gif`
- `*.pdf`
- `*.webp`
- `*.svg`
- `*.mp4`
- `*.mov`
- `*.mp3`
- `*.wav`
- `*.heic`
- `*.heif`

### Veiligheid

- **Dry-run modus**: Gebruik `--dry-run` om te zien wat verwijderd zou worden zonder daadwerkelijk te verwijderen
- **Bevestiging**: Je moet expliciet `--delete` opgeven om bestanden te verwijderen
- **Backups**: Maak altijd een backup van je vault voordat je de tool uitvoert!

## Opties

| Optie | Beschrijving | Standaard | Verplicht |
|-------|-------------|-----------|-----------|
| `<vault-path>` | Pad naar de Obsidian vault | - | ✅ Ja |
| `-d, --dry-run` | Alleen tonen, niet verwijderen | false | ❌ Nee |
| `-i, --include <patterns>` | Patronen voor attachment bestanden (komma-gescheiden) | `*.png,*.jpg,...` | ❌ Nee |
| `-e, --exclude <patterns>` | Patronen om uit te sluiten (komma-gescheiden) | - | ❌ Nee |
| `-q, --quiet` | Minder output tonen | false | ❌ Nee |
| `-v, --verbose` | Meer details tonen | false | ❌ Nee |
| `--delete` | Daadwerkelijk bestanden verwijderen | false | ❌ Nee |

## Veelgestelde Vragen

### Waarom wordt mijn attachment als "niet gebruikt" gemarkeerd?

Controleer of:
1. De exacte bestandsnaam (inclusief extensie) ergens in een markdown bestand staat
2. De attachment niet in een submap staat die uitgesloten is
3. De extensie in de include patronen staat

### Hoe kan ik specifieke mappen uitsluiten?

Gebruik de `--exclude` optie:
```bash
node index.js /pad/naar/vault --exclude "temp,backup,old"
```

### Kan ik de tool op meerdere vaults tegelijk uitvoeren?

Ja, voer de tool gewoon meerdere keren uit:
```bash
node index.js /pad/naar/vault1 --delete
node index.js /pad/naar/vault2 --delete
```

### Wat als ik per ongeluk iets verwijder?

**Maak altijd een backup!** De tool verwijdert bestanden definitief. Gebruik `--dry-run` om eerst te controleren.

## Bijdragen

Pull requests zijn welkom! Voor grote wijzigingen:

1. Fork de repository
2. Maak een feature branch (`git checkout -b feature/amazing-feature`)
3. Commit je wijzigingen (`git commit -m 'Voeg amazing feature toe'`)
4. Push naar de branch (`git push origin feature/amazing-feature`)
5. Open een Pull Request

## Licentie

Dit project is gelicenseerd onder de **MIT License**.

## Contact

Voor vragen, suggesties of problemen:
- GitHub Repository: https://github.com/Dominiekge/DG
- Open een Issue voor bug reports
- Open een Pull Request voor bijdragen

---

Gemaakt met ❤️ voor de Obsidian community
