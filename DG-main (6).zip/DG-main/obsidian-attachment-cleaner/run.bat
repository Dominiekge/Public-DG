@echo off
chcp 65001 >nul
title Obsidian Attachment Cleaner

:: Check if Node.js is installed
where node >nul 2>&1
if %errorlevel% neq 0 (
    echo ❌ Fout: Node.js is niet geïnstalleerd
    echo Installeer Node.js eerst: https://nodejs.org
    pause
    exit /b 1
)

:: Navigate to script directory
cd /d "%~dp0"

:: Check if dependencies are installed
if not exist "node_modules" (
    echo ℹ️  Afhankelijkheden installeren...
    npm install
)

:: Ask for vault path
set /p vaultPath=Voer het pad naar je Obsidian vault in:

if "%vaultPath%"=="" (
    echo ❌ Geen pad opgegeven
    pause
    exit /b 1
)

:: Check if path exists
if not exist "%vaultPath%" (
    echo ❌ Fout: Pad bestaat niet: %vaultPath%
    pause
    exit /b 1
)

:: Ask if user wants to delete or just scan
set /p mode=Wil je ongebruikte attachments VERWIJDEREN? (j/n, standaard=n):

if /i "%mode%"=="j" (
    echo.
    echo ⚠️  LET OP: Dit verwijdert ongebruikte attachments PERMANENT!
    set /p confirm=Weet je het zeker? Typ JA om door te gaan:
    if /i "%confirm%"=="JA" (
        node index.js "%vaultPath%" --delete
    ) else (
        node index.js "%vaultPath%"
    )
) else (
    node index.js "%vaultPath%"
)

echo.
pause
